angular.module('votingApp', [])
  .controller('YourController', function($scope, $http) {
    // Fetch data from PHP backend (get_candidates.php)
    $http.get('submit_vote.php')
      .then(function(response) {
        // If the response data is not empty, assign it to $scope.candidate_details
        if (response.data.length > 0) {
          $scope.candidate_details = response.data;
        } else {
          // Handle the case where no candidates are available for today
          $scope.candidate_details = [];
          alert('No candidates available for today.');
        }
      })
      .catch(function(error) {
        console.error("Error fetching candidate data:", error);
      });

    // Function to handle vote submission
    $scope.save_vote = function(candidateId) {
      alert('Vote submitted for candidate ID: ' + candidateId);
    };
  });

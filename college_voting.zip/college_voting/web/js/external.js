var app = angular.module('myApp', []);
app.controller('myController', function($scope, $http) {
    // Retrieve newId value from HTML data attribute
    var newIdElement = document.getElementById('newIdContainer');
    $scope.field_1 = newIdElement.getAttribute('data-newid');

    $scope.create_voter = function() {
        $http.post('create_voter.php', {
            'field_1': $scope.field_1,
            'field_2': $scope.field_2,
            'field_3': $scope.field_3,
            'field_4': $scope.field_4,
            'field_5': $scope.field_5,
            'field_6': $scope.field_6,
            'field_7': $scope.field_7,
            'field_9': $scope.field_9,
            'field_10': $scope.field_10,
            'field_11': $scope.field_11,
            'field_12': $scope.field_12,
            'email': $scope.cook_admin_email
        }).then(function(response) {
            var data = response.data;
            if (data.success == 1) {
                alert("Created Successfully");
                window.location = "home.html";
            } else if (data.success == 2) {
                alert("Please Fill All Fields");
            } else if (data.success == 3) {
                alert("Enter 10 Digit Number");
            } else if (data.success == 5) {
                alert("Student ID Already Exist");
            } else if (data.success == 6) {
                alert("Enter 6 Pincode Number");
            } else {
                alert("UnSuccessfully");
            }
        }).catch(function(error) {
            console.error('Error occurred:', error);
            alert("An error occurred while creating the voter.");
        });
    };
});

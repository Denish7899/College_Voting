function submitVote(candidateId) {
    // Send the candidateId to the PHP file
    fetch('submit_vote.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ candidateId: candidateId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Vote successfully submitted!");
            location.reload(); // Reload the page to disable the button
        } else {
            alert(data.message || "Failed to submit vote.");
        }
    })
    .catch(error => console.error('Error:', error));
}

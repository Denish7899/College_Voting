var app = angular.module("myapp", ['ngCookies']);
app.controller("myappCtrl", function($scope, $cookies, $cookieStore, $http) 
{
	
/****************************************************************************/
/************************** Get Admin Details ***********************************/
/****************************************************************************/	
	$scope.cook_admin_email = $cookieStore.get("cook_admin_email");
	$scope.cook_user_email = $cookieStore.get("cook_user_email");
	$scope.cook_user_ward = $cookieStore.get("cook_user_ward");
	$scope.cook_user_name = $cookieStore.get("cook_user_name");


	$scope.user_logout = function() 
	{
		if(confirm("Are You Sure?"))
		{
			$cookies.cook_user_email = "";
			$cookies.cook_user_ward = "";
			$cookies.cook_admin_email = "";
			window.location = "index.html";
			return;
		}
		else
		{
			return false;
		}
	}
	/****************************************************************************/
/************************** Generate OTP  *************************************/
/****************************************************************************/
	// sign in button
	$scope.generate_otp = function() 
	{		
        $http.post('generate_otp.php', 
			{'email': $scope.cook_user_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("OTP Sent Successful");
				window.location = "post_otp.html";  // Home Page
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 3)
			{
				alert("Election Date Expired");
			}
			else if(data.success == 4)
			{
				alert("Election Date & Time Not Started - Please Wait");
			}
			else
			{
				//alert("OTP Sent Successful");
				window.location = "post_otp.html";  // Home Page
				return;				
			}
        });
    }

/****************************************************************************/
/************************** Add Complaint *********************************/
/****************************************************************************/
	$scope.match_otp = function() 
	{		
		$http.post('match_otp.php', {
		'field_1':$scope.field_1,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("OTP Matched Successfully");
				window.location = "submit_vote.php";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("OTP Not Matched");
			}
        });
    }
/****************************************************************************/
/************************** submit voting *********************************/
/****************************************************************************/
	$scope.save_vote = function(field_2) 
	{		
		$http.post('save_vote.php', {
		'field_1':field_2,'ward':$scope.cook_user_ward,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Voting Submitted");
				window.location = "user_home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 4)
			{
				alert("Already Vote Submitted");
			}
			else
			{
				alert("Voting Unsuccessfully");
			}
        });
    }
/****************************************************************************/
/************************** Add Complaint *********************************/
/****************************************************************************/


	 $scope.assign_candidate = function(field_1) 
	{
		window.location = "post_canditate.html";
		$cookieStore.put("cook_field_5",field_1);
		return;
	}	
	
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	
	$scope.create_candidate = function() 
	{		
		$http.post('create_candidate.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.cook_field_5,'field_6':$scope.field_6,
		'field_7':$scope.field_7,'field_8':$scope.field_8,'field_9':$scope.field_9,'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "view_results.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 3)
			{
				alert("Enter 10 Digit Mobile No");
			}
			else if(data.success == 5)
			{
				alert("Candidate ID Already Exist");
			}
			else
			{
				alert("Please Fill All Fields");
			}
        });
    }
/****************************************************************************/
/************************** Add Complaint *********************************/
/****************************************************************************/
	$scope.create_voter = function() 
	{		
		$http.post('create_voter.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.field_5,'field_6':$scope.field_6,
		'field_7':$scope.field_7,'field_9':$scope.field_9,
		'field_10':$scope.field_10,'field_11':$scope.field_11,'field_12':$scope.field_12,
		'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 3)
			{
				alert("Enter 10 Digit Number");
			}
			else if(data.success == 5)
			{
				alert("Student ID Already Exist");
			}
			else if(data.success == 6)
			{
				alert("Enter 6 Pincode Number");
			}
			else
			{
				alert("UnSuccessfully");
			}
        });
    }
/****************************************************************************/
/************************** admin Details *********************************/
/****************************************************************************/
	$http.post('admin_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.admin_details = data.details;
		}
		else
		{
			$scope.admin_details = "No Data Found !!!";
		}
    });
/****************************************************************************/
/************************** Get All details  *********************************/
/****************************************************************************/
	$http.post('get_voter.php')
	.success(function(data, status, headers, config) 
	{
			$scope.details = data.details;
    });
	
	$http.post('get_sport.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.sport_details = data.details;
		}
		else
		{
			$scope.sport_details = "No Data Found !!!";
		}
    });
	
	$http.post('get_candidate.php')
	.success(function (response) 
	{
		$scope.candidate_details = response.details;
	});
	
	$http.post('get_election_date.php')
	.success(function (response) 
	{
		$scope.date_details = response.details;
	});
	
		$scope.update_image = function(cus_id) 
			{
				$cookieStore.put("cook_app_id",cus_id);
				window.location = "file.html";
				return;
			}
		$scope.cook_app_id = $cookieStore.get("cook_app_id");
/****************************************************************************/
/************************** Add Requriments *********************************/
/****************************************************************************/

/****************************************************************************/
/************************** Student Update *********************************/
/****************************************************************************/
$scope.update_student = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_9,field_10,field_11,field_12) 
	{
		window.location = "update_voter.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		$cookieStore.put("cook_field_7",field_7);
		$cookieStore.put("cook_field_9",field_9);
		$cookieStore.put("cook_field_10",field_10);
		$cookieStore.put("cook_field_11",field_11);
		$cookieStore.put("cook_field_12",field_12);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	$scope.cook_field_9 = $cookieStore.get("cook_field_9");
	$scope.cook_field_10 = $cookieStore.get("cook_field_10");
	$scope.cook_field_11 = $cookieStore.get("cook_field_11");
	$scope.cook_field_12 = $cookieStore.get("cook_field_12");

	$scope.save_voter = function() 
	{		
		$http.post('save_voter.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5,
		'field_6':$scope.cook_field_6,'field_7':$scope.cook_field_7,
		'field_9':$scope.cook_field_9,'field_10':$scope.cook_field_10,'field_11':$scope.cook_field_11,
		'field_12':$scope.cook_field_12
		
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "view_voter.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
/****************************************************************************/
/************************** Election Date *********************************/
/****************************************************************************/
$scope.edit_election_date = function(field_1,field_2,field_3,
								 field_4) 
	{
		window.location = "update_date.html";
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		return;
	}	
	
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");

	$scope.save_date = function() 
	{		
		$http.post('save_date.php',{
		'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4
		
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Updated successfully");
				window.location = "view_date.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
/****************************************************************************/
/************************** User Update *********************************/
/****************************************************************************/
	
		$http.post('get_user_info.php',
		{
			'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
				$scope.userdetails = data.details;
			   
          });
		  
		$http.post('get_voting.php',
		{
			'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
				$scope.ward_details = data.details;
         });
		  
$scope.user_update_info = function(name,password,mobile) 
	{
		window.location = "user_info_edit.html";
		$cookieStore.put("cook_name",name);
		$cookieStore.put("cook_password",password);
		$cookieStore.put("cook_mobile",mobile);
		return;
	}	
	
	$scope.cook_name = $cookieStore.get("cook_name");
	$scope.cook_password = $cookieStore.get("cook_password");
	$scope.cook_mobile = $cookieStore.get("cook_mobile");

	$scope.save_update_info = function() 
	{		
		$http.post('user_update_info.php',{
		 'name':$scope.cook_name, 'password':$scope.cook_password,
		 'mobile': $scope.cook_mobile, 'email': $scope.cook_admin_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "user_update_info.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	
	
/****************************************************************************/
/************************** Candidate Update *********************************/
/****************************************************************************/
$scope.update_candidate = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_8,field_9) 
	{
		window.location = "update_candidate.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		$cookieStore.put("cook_field_7",field_7);
		$cookieStore.put("cook_field_8",field_8);
		$cookieStore.put("cook_field_9",field_9);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	$scope.cook_field_8 = $cookieStore.get("cook_field_8");
	$scope.cook_field_9 = $cookieStore.get("cook_field_9");
	
	$scope.save_candidate = function() 
	{		
		$http.post('save_candidate.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5,
		'field_6':$scope.cook_field_6,'field_7':$scope.cook_field_7,'field_8':$scope.cook_field_8,
		'field_9':$scope.cook_field_9
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "view_results.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
	 
	 $scope.upload_photo = function(cus_id) 
	{
		window.location = "file.html";
		$cookieStore.put("cook_cus_id",cus_id);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	 
		 
/****************************************************************************/
/************************** Delete Candidate *********************************/
/****************************************************************************/
	$scope.delete_candidate = function(cus_id) 
	{		
        $http.post('delete_candidate.php', 
		{
		'id':cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Deleted Successful");
				window.location = "view_results.php";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting !!");
			}
			else
			{
				alert("No id found");
			}
        });
    }

	$scope.delete_student = function(cus_id) 
	{		
        $http.post('delete_student.php', 
		{
		'id':cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Deleted Successful");
				window.location = "view_voter.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting !!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
});

////////////////////////////////////////////////


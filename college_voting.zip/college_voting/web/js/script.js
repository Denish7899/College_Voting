// Function to filter the table based on search input
function searchTable() {
    var input = document.getElementById("searchInput");
    var filter = input.value.toUpperCase(); // Get search term in uppercase
    var table = document.getElementById("candidateTable");
    var tr = table.getElementsByTagName("tr"); // Get all table rows

    // Loop through each row (skip the first row, which is the table header)
    for (var i = 1; i < tr.length; i++) {
        var td = tr[i].getElementsByTagName("td");
        var rowContainsMatch = false;

        // Loop through all columns (except the last "Actions" column)
        for (var j = 1; j < td.length - 1; j++) {  // Skipping the first column (image) and last (actions)
            if (td[j]) {
                var textValue = td[j].textContent || td[j].innerText;
                // Check if the cell's text contains the search term
                if (textValue.toUpperCase().indexOf(filter) > -1) {
                    rowContainsMatch = true;
                    break; // Stop searching once a match is found
                }
            }
        }

        // Show or hide the row based on whether it matches the search term
        if (rowContainsMatch) {
            tr[i].style.display = "";
        } else {
            tr[i].style.display = "none"; // Hide the row if it doesn't match
        }
    }
}

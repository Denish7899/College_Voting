<!DOCTYPE html>
<html ng-app="myapp">
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" >
		<meta name="author" >

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="fonts/font.css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.theme.css" media="screen">
		<link href="vendor/owl-carousel/owl.transitions.html" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="vendor/flexslider/flexslider.css" media="screen">
		<link rel="stylesheet" href="vendor/chosen/chosen.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">
        <link rel="stylesheet" href="css/colors/style.css" media="screen">

        <link rel="stylesheet" href="css/datetimepicker.less" media="screen">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-animate.css">

		<!-- Style Switcher-->

		<!-- Head libs -->
		<script src="vendor/modernizr/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->


			<script src="vendor/respond/respond.js"></script>
			<script src="vendor/excanvas/excanvas.js"></script>
            <link rel="stylesheet" type="text/css" href="css/DateTimePicker.css" />

            <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
            <script type="text/javascript" src="js/DateTimePicker.js"></script>


            <link rel="stylesheet" type="text/css" href="css/DateTimePicker-ltie9.css" />
            <script type="text/javascript" src="js/DateTimePicker-ltie9.js"></script>


        <style>
			.page-wrap {
                max-width: 75rem;
                margin: 0 auto;
            }

            h1 {

                font-size: 1.5rem;
                letter-spacing: -1px;
                margin: 1.25rem 0;
            }

            input:focus ~ label, textarea:focus ~ label, input:valid ~ label, textarea:valid ~ label {
                font-size: 0.75em;

                top: -2.25rem;
                -webkit-transition: all 0.125s ease;
                transition: all 0.125s ease;
            }

            .styled-input {
				left:10px;
                width: 90%;
                margin: 2rem 0 1rem;
                position: relative;
            }

            .styled-input label {
                color: #999;
                padding: 1rem;
                position: absolute;
                top: 0;
                left: 0;
                -webkit-transition: all 0.25s ease;
                transition: all 0.25s ease;
                pointer-events: none;
            }



            input,
            textarea {
			font-weight:bold;
                position: relative;
                height: 2.9em;
                border: 0px solid #bebebe;
                border-bottom-width: 1px;
                width: 100%;
            }

            input ~ span,
            textarea ~ span {
                display: block;
                width: 0;
                height:1px;
                background: #FF6929;
                position: absolute;
                bottom: 0;
                left: 0;
                -webkit-transition: all 0.125s ease;
                transition: all 0.125s ease;
            }

            input:focus,
            textarea:focus { outline: 0; }

            input:focus ~ span,
            textarea:focus ~ span {
                width: 100%;
                -webkit-transition: all 0.075s ease;
                transition: all 0.075s ease;
            }

            textarea {
                width: 100%;
                min-height: 15em;
            }
        </style>

<!-- script back button -->
<script>
	window.addEventListener('load', function()
	 {
		history.pushState(null, document.title, location.href);
		window.addEventListener('popstate', function(event)
		{
			history.pushState(null, document.title, location.href);            
		});
	});
</script>


	<!-- angular js -->
	<script src="js/angular-1.3.js"></script>
	<script src="js/angular_cookies.js"></script>
	
	</head>
	<body   ng-controller="myappCtrl" style="background-color: #EEEEEE" class="front bg-pattern-dark">
		<div class="body">
			<header id="header">
				<div class="header-top" style="height:8em;">
					<div class="container">
						<a href="#offcanvas" class="uk-navbar-toggle" style="float:left; margin:50px 5px 10px 5px;" data-uk-offcanvas>
							<span class="sr-only">Toggle navigation</span>
							<i class="fa fa-bars"></i>
						</a>
                        <nav>
							<ul class="nav nav-pills nav-top nav-top-left">
								<div class="head">College Voting System</div>
							</ul>
														
							<ul class="nav nav-pills nav-top nav-top-right">
								<li class="login">
									
								</li>
							</ul>
                        </nav>
					</div>	
				</div>
			</header>
			
			<br>
			<div style="font-weight: 100;font-size: 1.6em ;text-align: center;color: #000000" >Allocate Candidate</div>
			<br>

    <?php
        include "db_connect.php";

        $todayDate = date('Y-m-d');

        if (isset($_POST['btnassign']))
        {
        $cname = $_POST['name'] ?? '';
        $id = $_POST['id'] ?? '';
        $department = $_POST['department'] ?? '';
        $year = $_POST['year'] ?? '';
        $date = $_POST['date'] ?? '';
        $gender= $_POST['gender'] ?? '';
        $add = $_POST['address'] ?? '';
        $mobile = $_POST['mobile'] ?? '';
        $position = $_POST['position'] ?? '';
        $email = $_POST['email'] ?? 'admin@gmail.com';
        if (empty($mobile) || empty($cname) || empty($id) || empty($gender) || empty($add)|| empty($date) || empty($department) || empty($year) || empty($position))
        {
            echo "<script>alert('Please fill all required fields.');</script>";
        } 

        $stmt = $conn->prepare("INSERT INTO candidate (email,candidate_name,id,department,year,date,gender,address,mobile,Position,created_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param('sssssssssss',$email,$cname,$id,$department,$year,$date,$gender,$add,$mobile,$position,$todayDate);
            if ($stmt->execute())
            {
                echo "<script>alert('Data added successfully');
                window.location.href = 'post_canditate.php';
                </script>";
            }
            else 
            {
                echo "<script>alert('Error: " . $stmt->error . "');</script>";
            }
            $stmt->close();
        } 
        $conn->close();
    ?>
			
                <div class="container">
                    <form class="form" method="post" autocomplete="off">

					<div class="styled-input">
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($cname ?? ''); ?>" ng-pattern="/^[A-Za-z\s]+$/" oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')" />
                        <label for="name">Candidate Name</label>
                    </div>
                        
                    <div class="styled-input">
                        <input type="text" id="id" name="id" value="<?php echo htmlspecialchars($id ?? ''); ?>"/>
                        <label for="id">Student Id</label>
                    </div>

                    <div class="styled-input">
                    <select id="position" name="position" value="<?php echo htmlspecialchars($position ?? ''); ?>" required>
                        <option value="">Select Position</option>
                        <option value="CR">CR</option>
                        <option value="LR">LR</option>
                        <option value="GS">GS</option>
                        <option value="WISE(GS)">WISE(GS)</option>
                    </select>
                    </div>

                        <div class="styled-input">
                        <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($date ?? ''); ?>"/>
						<label for="assigndate">Assign Date</label>
                        </div>

                        <div class="styled-input">
                        <select id="gender" name="gender" value="<?php echo htmlspecialchars($gender ?? ''); ?>" required>
                            <option value="">Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
						</div>

                        <div class="styled-input">						
                        <input type="text" id="mobile" name="mobile" value="<?php echo htmlspecialchars($mobile ?? ''); ?>" maxlength="10" pattern="^[0-9]{10}$" ng-pattern="/^[0-9]*$/" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                        <label for="Mobile">Mobile</label>
                        </div>

						<div class="styled-input">
                        <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($add ?? ''); ?>" maxlength="80"/>
                        <label for="address">Address</label>
                        </div>

                        <div class="styled-input">
                        <select id="department" name="department" value="<?php echo htmlspecialchars($department ?? ''); ?>">
                        <option value="">Select Department</option>
                        <option value="BMIIT">BMIIT</option>
                        <option value="CGPIT">CGPIT</option>
                        <option value="BBA">BBA</option>
                        <option value="MBA">MBA</option>
                        </select>				
                        </div>

                        <div class="styled-input">
                        <select id="year" name="year" value="<?php echo htmlspecialchars($year ?? ''); ?>">
                        <option value="">Select Year</option>
                        <option value="1st">1st</option>
                        <option value="2nd">2nd</option>
                        <option value="3rd">3rd</option>
                        <option value="4th">4th</option>
                        <option value="5th">5th</option>
                        </select>
                        </div>
                        <input type="submit" name="btnassign" value="Allocate" style="background-color: #FF6929; color: white; border: none; padding: 10px 20px; padding-left: 30px;cursor: pointer;">
                    </form>	
                    </div>
				</div>
        </div> 
		<br>
		</div>

        </div>
		<div id="offcanvas" class="uk-offcanvas">
            <div class="uk-offcanvas-bar">
				<ul id="main-menu-offcanvas" class="uk-nav-offcanvas" data-uk-nav>
					<h2 style="color:#000;font-size:25px;padding:1.5em;margin-bottom:15px;font-weight:bold;font-family:Quicksand;">Online Portal</h2>
					<span class="uk-parent">
						<a href="home.html"><img src="images/icons/house.png" class="fa icon"> &nbsp;&nbsp;&nbsp;Home</a>
					</span>
                    
                    <span class="uk-parent">
						<a style="cursor:pointer" ng-click="user_logout()"><img src="images/icons/smartphone-2.png" class="fa icon"> &nbsp;&nbsp;&nbsp;Logout</a>
					</span>
				</ul>
			</div>
		</div>
		

		<!-- Begin Style Switcher -->
	
		<!-- Vendor -->
			<script src="vendor/jquery.validation/jquery.validation.js"></script>
		<script src="vendor/owlcarousel/owl.carousel.js"></script>
		<script src="vendor/flexslider/jquery.flexslider-min.js"></script>
		<script src="vendor/countdown/countdown.min.js"></script>
		<script src="vendor/chosen/chosen.jquery.min.js"></script>
		<script src="vendor/pricefilter/jquery.pricefilter.js"></script>
		<script src="vendor/masonry/imagesloaded.pkgd.min.js"></script>
		<script src="vendor/masonry/masonry.pkgd.min.js"></script>
		<script src="vendor/uikit/uikit.js"></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>

		<!-- Theme Base, Components and Settings -->
		<script src="js/theme.js"></script>
		
		<!-- Style Switcher -->
		<script type="text/javascript" src="style-switcher/js/switcher.js"></script>


        <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
        <script type="text/javascript" src="js/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
        <script type="text/javascript">
            $('.form_datetime').datetimepicker({
                //language:  'fr',
                weekStart: 1,
                todayBtn:  1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: 1
            });
            $('.form_date').datetimepicker({
                language:  'fr',
                weekStart: 1,
                todayBtn:  1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                minView: 2,
                forceParse: 0
            });
            $('.form_time').datetimepicker({
                language:  'fr',
                weekStart: 1,
                todayBtn:  1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 1,
                minView: 0,
                maxView: 1,
                forceParse: 0
            });
        </script>
<body onload="onLoad()">		
</body>
</html>
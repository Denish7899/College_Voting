    <?php
    	// Account details
    	
	$username = "contact@arudhrainnovations.com";
	$apiKey = urlencode('gFiNovbuwFA-Sq6GSGPLvCfzHKWRcQBbuzlt0ChGEK');
	$test = "0";
     
	 

	$sender = urlencode('AISOFT');

    	// Message details
    	$numbers = "9790675343";
		$get_otp = rand(10000,99000);

	$message = 'Your OTP '.$get_otp.' to verify your mobile number by AISOFT';

	$message = rawurlencode($message);
	
     
    	// Prepare data for POST request
    	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
     
    	// Send the POST request with cURL
    	$ch = curl_init('https://api.textlocal.in/send/');
    	curl_setopt($ch, CURLOPT_POST, true);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	$response = curl_exec($ch);
    	curl_close($ch);
    	
    	// Process your response here
    	echo $response;
    ?>
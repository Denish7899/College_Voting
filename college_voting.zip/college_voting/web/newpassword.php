<?php
/* Following code will match admin login credentials */

// User temp array
$response = array();

// Include db connect class
require_once __DIR__ . '/db_connect.php';


// Get input data
$data = json_decode(file_get_contents("php://input"));

// Hardcoded for testing, replace with actual input data
$get_empid =  ($data->email);
$get_password =($data->password);
$get_field_3 = ($data->field_3);
$get_field_4 =  ($data->field_4);

// Check for empty fields
if (empty($get_empid) || empty($get_password) || empty($get_field_3) || empty($get_field_4)) {
    $response["success"] = 2;
    echo json_encode($response);
    exit;
} else {
    // Prepare the SQL statement with all conditions
    $stmt = $conn->prepare("SELECT * FROM admin_login WHERE email = ? AND question1 = ? AND question2 = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("sss", $get_empid, $get_field_3, $get_field_4);

    // Execute the query
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if there is a matching record
    if ($result->num_rows > 0) {
		
		$result2 = mysqli_query($conn,"update admin_login SET password = '$get_password' where email = '$get_empid'");

        // Valid credentials
        $response["success"] = 1;
    } else {
        // Invalid credentials
        $response["success"] = 0;
    }

    // Echo the response as JSON
    echo json_encode($response);

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

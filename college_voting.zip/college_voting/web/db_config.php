<?php
/*
* All database connection variables
*/

define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db passwords
define('DB_DATABASE', "college_voting_maniya"); // database name
define('DB_SERVER', "localhost"); // db server

?>
<?php 
session_start();
include "db_connect.php";

$apply_year = isset($_POST['apply_year']) ? intval($_POST['apply_year']) : date("Y");

$user_query = "SELECT email, candidate_name, id, department, year, date, gender, address, mobile, COUNT(*) AS count 
               FROM candidate 
               WHERE YEAR(created_date) = $apply_year 
               GROUP BY candidate_name";
$user_result = $conn->query($user_query);
if (!$user_result) {
    die("Query failed: " . $conn->error);
}
// Check if the query returned any results
if ($user_result->num_rows > 0) {
    // Fetch the candidate with the maximum votes
    $winner_query = "SELECT candidate_name, MAX(count) AS max_votes 
                     FROM (SELECT candidate_name, COUNT(*) AS count 
                           FROM candidate 
                           WHERE YEAR(created_date) = $apply_year 
                           GROUP BY candidate_name) AS vote_counts";
    $winner_result = $conn->query($winner_query);
    if (!$winner_result) {
        die("Query failed: " . $conn->error);
    }

    $winner = $winner_result->fetch_assoc();
} else {
    $winner = null;
}
?>


<!DOCTYPE html>
<html ng-app="myapp">
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" >
		<meta name="theme-color" content="#fc9f11" />

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="fonts/font.css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.theme.css" media="screen">
		<link href="vendor/owl-carousel/owl.transitions.html" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="vendor/flexslider/flexslider.css" media="screen">
		<link rel="stylesheet" href="vendor/chosen/chosen.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-animate.css">
		
		<!-- Style Switcher-->

		<!-- Head libs -->
		<script src="vendor/modernizr/modernizr.js"></script>

        <style>
            .page-wrap {
                max-width: 75rem;
                margin: 0 auto;
            }

            h1 {

                font-size: 1.5rem;
                letter-spacing: -1px;
                margin: 1.25rem 0;
            }

            input:focus ~ label, textarea:focus ~ label, input:valid ~ label, textarea:valid ~ label {
                font-size: 0.75em;

                top: -2.25rem;
                -webkit-transition: all 0.125s ease;
                transition: all 0.125s ease;
            }

            .styled-input {
                left:10px;
                width: 90%;
                margin: 2rem 0 1rem;
                position: relative;
            }

            .styled-input label {
                color: #999;
                padding: 1rem;
                position: absolute;
                top: 0;
                left: 0;
                -webkit-transition: all 0.25s ease;
                transition: all 0.25s ease;
                pointer-events: none;
            }
            input,
            textarea {
                position: relative;
                height: 2.9em;
                border: 0px solid #bebebe;
                border-bottom-width: 1px;
                width: 100%;
            }

            input ~ span,
            textarea ~ span {
                display: block;
                width: 0;
                height:1px;
                background: #FF6929;
                position: absolute;
                bottom: 0;
                left: 0;
                -webkit-transition: all 0.125s ease;
                transition: all 0.125s ease;
            }

            input:focus,
            textarea:focus { outline: 0; }

            input:focus ~ span,
            textarea:focus ~ span {
                width: 100%;
                -webkit-transition: all 0.075s ease;
                transition: all 0.075s ease;
            }

            textarea {
                width: 100%;
                min-height: 15em;
            }
        </style>

<!-- script back button -->
<script>
	window.addEventListener('load', function()
	 {
		history.pushState(null, document.title, location.href);
		window.addEventListener('popstate', function(event)
		{
			history.pushState(null, document.title, location.href);            
		});
	});
</script>


	<!-- angular js -->
	<script src="js/angular-1.3.js"></script>
	<script src="js/angular_cookies.js"></script>

	</head>
	<body ng-controller="myappCtrl" class="front bg-pattern-dark">
		<div class="body">
			<header id="header">
				<div class="header-top" style="height:8em;">
					<div class="container">
						<a href="#offcanvas" class="uk-navbar-toggle" style="float:left; margin:50px 5px 10px 5px;" data-uk-offcanvas>
							<span class="sr-only">Toggle navigation</span>
							<i class="fa fa-bars"></i>
						</a>
                        <nav>
							<ul class="nav nav-pills nav-top nav-top-left">
								<div class="head">College Voting System</div>
							</ul>
							<ul class="nav nav-pills nav-top nav-top-right">
								<li class="login">
									
								</li>
							</ul>
                        </nav>
					</div>	
				</div>
			</header>
		</div>
	</div>
	
        <div class="modal fade form-wrapper" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
            </div>
        </div>

		<div id="offcanvas" class="uk-offcanvas">
            <div class="uk-offcanvas-bar">
				<ul id="main-menu-offcanvas" class="uk-nav-offcanvas" data-uk-nav>
					<h2 style="color:#000;font-size:25px;padding:1.5em;margin-bottom:15px;font-weight:bold;font-family:Quicksand;">Online Portal</h2>
					<span class="uk-parent">
						<a href="home.html"><img src="images/icons/house.png" class="fa icon"> &nbsp;&nbsp;&nbsp;Home</a>
					</span>
                    
                    <span class="uk-parent">
						<a style="cursor:pointer" ng-click="user_logout()"><img src="images/icons/smartphone-2.png" class="fa icon"> &nbsp;&nbsp;&nbsp;Logout</a>
					</span>
				</ul>
			</div>
		</div>
		
		<div class="content" style="margin-top:3em">
		<div class="container" ng-repeat="x in details | filter : search_field |orderBy:'cus_id':true">
			<section class="content-inner">
				<div class="row">
				</div>
				</section>
			</div>

				<!-- Search Results --> 
				<h2 class="content-sub-heading" style="text-align:center;font-size:40px;color:rgb(69,90,100);font-weight:200">View Student List</h2>
				<div style="position: relative;left: 10px;"></div>

				<style>
    /* Basic table styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 1em;
        font-family: Arial, sans-serif;
    }

    /* Header styling */
    th {
        background-color: #4CAF50;
        color: white;
        padding: 12px;
        text-align: left;
    }

    /* Cell styling */
    td {
        padding: 12px;
        border-bottom: 1px solid #ddd;
    }

    /* Alternating row colors */
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    /* Hover effect for rows */
    tr:hover {
        background-color: #ddd;
    }

    /* Table border */
    table, th, td {
        border: 1px solid #ddd;
    }
            input[type="number"], input[type="submit"] {
                padding: 8px;
                margin: 10px 0;
                font-size: 1rem;
            }
            input[type="submit"] {
                background-color: #4CAF50;
                color: white;
                border: none;
                cursor: pointer;
            }
            input[type="submit"]:hover {
                background-color: #45a049;
            }
</style>

        <form method="post" action="">
        <div class="styled-input">
        Enter Year:<input type="text" id="apply_year" name="apply_year" value="<?php echo $apply_year; ?>" min="2000" max="<?php echo date("Y"); ?>" required onchange="this.form.submit()>
        </div>
        </form>

        <?php if ($winner): ?>
            <h2>The Winner for <?php echo $apply_year; ?> is: <?php echo htmlspecialchars($winner['candidate_name']); ?> with <?php echo htmlspecialchars($winner['max_votes']); ?> votes.</h2>
        <?php elseif ($apply_year): ?>
            <h2>No details available for the year <?php echo $apply_year; ?>.</h2>
        <?php endif; ?>   
            <div class="table-responsive">
            <?php if ($user_result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Email</th>
                    <th>Candidate Name</th>
                    <th>Department</th>
                    <th>Year</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Mobile</th>
                    <th>Votes</th>
                </tr>
                <?php while ($user = $user_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['candidate_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['department']); ?></td>
                        <td><?php echo htmlspecialchars($user['year']); ?></td>
                        <td><?php echo htmlspecialchars($user['gender']); ?></td>
                        <td><?php echo htmlspecialchars($user['address']); ?></td>
                        <td><?php echo htmlspecialchars($user['mobile']); ?></td>
                        <td><?php echo htmlspecialchars($user['count']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php endif; ?>
                </div>
                

		<div class="table-responsive card">
		<table class="table table-hover table-stripe" title="Default Tabl">
		</div>
	
		<script src="vendor/jquery/jquery.js"></script>
		<script src="vendor/bootstrap/bootstrap.js"></script>
		<script src="vendor/jquery.validation/jquery.validation.js"></script>
		<script src="vendor/owlcarousel/owl.carousel.js"></script>
		<script src="vendor/flexslider/jquery.flexslider-min.js"></script>
		<script src="vendor/countdown/countdown.min.js"></script>
		<script src="vendor/chosen/chosen.jquery.min.js"></script>
		<script src="vendor/pricefilter/jquery.pricefilter.js"></script>
		<script src="vendor/masonry/imagesloaded.pkgd.min.js"></script>
		<script src="vendor/masonry/masonry.pkgd.min.js"></script>
		<script src="vendor/uikit/uikit.js"></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
		
		<!--
		 Theme Base, Components and Settings -->
		<script src="js/theme.js"></script>
		
		<!-- Style Switcher -->
		<script type="text/javascript" src="style-switcher/js/switcher.js"></script>
		
	<!-- angular js -->
	<script src="js/angular_data.js"></script>
<body onload="onLoad()">		
</body>
</html>		
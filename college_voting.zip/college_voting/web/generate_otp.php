<?php
/* Following code will match admin login credentials */

//user temp array
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db


// check for post data
$data = json_decode(file_get_contents("php://input"));
$get_empid = ($data->email);
$get_admin = "admin@gmail.com";

date_default_timezone_set('Asia/Kolkata');

$result = mysqli_query($conn,"SELECT * FROM election_date WHERE email = '$get_admin' ");
$Allresponse1 = mysqli_fetch_array($result);
$start_date = $Allresponse1["start_date"];
$start_time = $Allresponse1["start_time"];
$end_date = $Allresponse1["end_date"];
$end_time = $Allresponse1["end_time"];


$start_date_time = $start_date.'-'.$start_time;
$end_date_time = $end_date.'-'.$end_time;



if(empty($get_empid) || empty($start_date) || empty($start_time) ||empty($end_date) ||empty($end_time)  )
{
	$response["success"] = 2;
	echo json_encode($response);
}
else
{
	// 2024-04-06 <=  2024-04-08				05:00 <= 06:52
		if (($start_date_time <= date('Y-m-d-H:i')) ) // start at min time 
		{
					// 2024-04-16 >=  2024-04-15    	
				if ( ($end_date_time >= date('Y-m-d-H:i'))  )
					{
			
			///////////////////////////////////////////////	
			///////////////////////////////////////////////	
			$result = mysqli_query($conn,"SELECT * FROM student WHERE student_id = '$get_empid' ");

				if (mysqli_num_rows($result))
				{
					$Allresponse = mysqli_fetch_array($result);
					// temp user array
					$details = array();
					$details = $Allresponse;
					$get_mobile = $Allresponse["mobile"];
					$get_otp = rand(10000,99000);
					
					mysqli_query($conn,"UPDATE student SET otp_2='$get_otp' WHERE student_id = '$get_empid' ");
					
					mysqli_query($conn,"UPDATE sms_count SET  count=count+1   ");

					//array_push($response["details"],$details);
					$response["success"] = 1;
					echo json_encode($response);
					
					/////////////////////////////////////////////////
					///////////////////SMS /////////////////////
					/////////////////////////////////////////////////

						// Authorisation details
					$username = "contact@arudhrainnovations.com";
					$apiKey = urlencode('gFiNovbuwFA-Sq6GSGPLvCfzHKWRcQBbuzlt0ChGEK');
					$test = "0";

					$sender = urlencode('AISOFT');
					$numbers = $get_mobile; // A single number or a comma-seperated list of numbers

					$message = 'Your OTP '.$get_otp.' to verify your mobile number by AISOFT';


					$message = rawurlencode($message);
					$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
				
					$ch = curl_init('https://api.textlocal.in/send/');
					curl_setopt($ch, CURLOPT_POST, true);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$result2 = curl_exec($ch); // This is the result from the API
							curl_close($ch);
				} 
				else
				{
					// success	
					$response["success"] = 0;
					// echoing JSON response
					echo json_encode($response);
				}
				///////////////////////////////////////////////	
				///////////////////////////////////////////////	
	
						
					}
					else
					{
							$response["success"] = 3;			//Survey Expired
							echo json_encode($response);
					}

		}
		else
		{
			// unsuccess
			$response["success"] = 4;		//Survey Not Started Pls Wait
			// echoing JSON response
			echo json_encode($response);
		}
		
	
}
?>
<?php
include "db_connect.php";

$isEditMode = false;
$todayDate = date('Y-m-d');

if (isset($_POST['btnassign']))
{
    $cname = $_POST['name'] ?? '';
    $sid = $_POST['sid'] ?? '';
    $department = $_POST['department'] ?? '';
    $year = $_POST['year'] ?? '';
    $date = $_POST['date'] ?? '';
    $gender= $_POST['gender'] ?? '';
    $add = $_POST['address'] ?? '';
    $mobile = $_POST['mobile'] ?? '';
    $position = $_POST['position'] ?? '';
    $email = $_POST['email'] ?? 'admin@gmail.com';
    if (empty($mobile) || empty($cname) || empty($sid) || empty($gender) || empty($add)|| empty($date) || empty($department) || empty($year) || empty($position))
    {
        echo "<script>alert('Please fill all required fields.');</script>";
    } 

        $stmt = $conn->prepare("INSERT INTO candidate (email,candidate_name,id,department,year,date,gender,address,mobile,Position,created_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param('sssssssssss',$email,$cname,$sid,$department,$year,$date,$gender,$add,$mobile,$position,$todayDate);
        if ($stmt->execute()) {
            echo "<script>alert('Data added successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
        header("Location: index.php");
    }

    if (isset($_POST['btndelete'])) {
        $id = $_POST['id'];
        $stmt = $conn->prepare("DELETE FROM candidate WHERE id = ?");
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "<script>alert('Record deleted successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }

    if (isset($_POST['btnUpdate']))
    {
    $cname = $_POST['name'] ?? '';
    $sid = $_POST['sid'] ?? '';
    $department = $_POST['department'] ?? '';
    $year = $_POST['year'] ?? '';
    $date = $_POST['date'] ?? '';
    $gender= $_POST['gender'] ?? '';
    $add = $_POST['address'] ?? '';
    $mobile = $_POST['mobile'] ?? '';
    $position = $_POST['position'] ?? '';
    $email = $_POST['email'] ?? 'admin@gmail.com';
    $originalId = $_POST['original_id'];

        $stmt = $conn->prepare("UPDATE candidate SET candidate_name = ?, id = ?, Department = ?, Year = ?, date = ?, Gender = ?,address = ?,mobile = ?,Position = ? WHERE id = ?");
        $stmt->bind_param('sssssssssi',$cname,$sid,$department,$year,$date,$gender,$add,$mobile,$position,$originalId);
        if ($stmt->execute())
        {
        } 
        else 
        {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }

    if (isset($_POST['btnEdit'])) {
    $isEditMode = true;
    $id = $_POST['id'];
    $stmt = $conn->prepare("SELECT * FROM candidate WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute())
    {
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $cname = $row['candidate_name'] ?? '';
        $sid = $row['id'] ?? '';
        $department = $row['Department'] ?? '';
        $year = $row['Year'] ?? '';
        $date = $row['date'] ?? '';
        $gender=$row['Gender'] ?? '';
        $add =$row['address'] ?? '';
        $mobile = $row['mobile'] ?? '';
        $position =$row['Position'] ?? '';
        $email = $row['email'] ?? 'admin@gmail.com';
    } 
    else 
    {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}
$result = $conn->query("SELECT * FROM candidate");
    if ($result === false)
    {
    die("Error fetching data: " . $conn->error);
    }
$conn->close();
?>

<!DOCTYPE html>
<html ng-app="myapp">
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" >
		<meta name="author" >

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="fonts/font.css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.theme.css" media="screen">
		<link href="vendor/owl-carousel/owl.transitions.html" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="vendor/flexslider/flexslider.css" media="screen">
		<link rel="stylesheet" href="vendor/chosen/chosen.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">
        <link rel="stylesheet" href="css/colors/style.css" media="screen">

        <link rel="stylesheet" href="css/datetimepicker.less" media="screen">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-animate.css">

		<!-- Style Switcher-->

		<!-- Head libs -->
		<script src="vendor/modernizr/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->


			<script src="vendor/respond/respond.js"></script>
			<script src="vendor/excanvas/excanvas.js"></script>
            <link rel="stylesheet" type="text/css" href="css/DateTimePicker.css" />

            <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
            <script type="text/javascript" src="js/DateTimePicker.js"></script>


            <link rel="stylesheet" type="text/css" href="css/DateTimePicker-ltie9.css" />
            <script type="text/javascript" src="js/DateTimePicker-ltie9.js"></script>


        <style>
			.page-wrap {
                max-width: 75rem;
                margin: 0 auto;
            }

            h1 {

                font-size: 1.5rem;
                letter-spacing: -1px;
                margin: 1.25rem 0;
            }

            input:focus ~ label, textarea:focus ~ label, input:valid ~ label, textarea:valid ~ label {
                font-size: 0.75em;

                top: -2.25rem;
                -webkit-transition: all 0.125s ease;
                transition: all 0.125s ease;
            }

            .styled-input {
				left:10px;
                width: 90%;
                margin: 2rem 0 1rem;
                position: relative;
            }

            .styled-input label {
                color: #999;
                padding: 1rem;
                position: absolute;
                top: 0;
                left: 0;
                -webkit-transition: all 0.25s ease;
                transition: all 0.25s ease;
                pointer-events: none;
            }

            input,
            textarea {
                position: relative;
                height: 2.9em;
                border: 0px solid #bebebe;
                border-bottom-width: 1px;
                width: 100%;
            }

            input ~ span,
            textarea ~ span {
                display: block;
                width: 0;
                height:1px;
                background: #03a3e8;
                position: absolute;
                bottom: 0;
                left: 0;
                -webkit-transition: all 0.125s ease;
                transition: all 0.125s ease;
            }

            input:focus,
            textarea:focus { outline: 0; }

            input:focus ~ span,
            textarea:focus ~ span {
                width: 100%;
                -webkit-transition: all 0.075s ease;
                transition: all 0.075s ease;
            }

            textarea {
                width: 100%;
                min-height: 15em;
            }
            body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .form-container {
            background: #fff;
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h1 {
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="file"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }

        #candidateTable {
            width: 97%;
            margin-left: 11px;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 12px;
            overflow: hidden;
            font-family: Arial, sans-serif;
            color: #333;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        #candidateTable thead {
            background-color: #6366f1;
            color: #ffffff;
        }

        #candidateTable thead th {
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            font-size: 15px;
            font-family: Arial, sans-serif;
        }

        #candidateTable tbody tr {
            background-color: #f9fafb;
            transition: background-color 0.3s ease;
        }

        #candidateTable tbody tr:nth-child(even) {
            background-color: #f1f5f9;
        }

        #candidateTable tbody tr:hover {
            background-color: #e5e7eb;
        }

        #candidateTable tbody td {
            padding: 10px 15px;
            border-bottom: 1px solid #e5e7eb;
            font-size: 17px;
            color: #4b5563;
        }

        #candidateTable tbody td img {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            object-fit: cover;
        }

        #candidateTable tbody tr:last-child td {
            border-bottom: none;
        }


        button-container {
            display: flex;
            justify-content: space-between; 
            width: 180px; 
        }

        .button {
            font-size: 14px;
            padding: 6px 12px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 85px; 
        }

        .button.edit {
            background-color: #4caf50;
            margin-right: 10px;
            color: #ffffff;
            cursor: pointer;
            background: linear-gradient(#6366f1, #4f46e5);
        }

        .button.edit:hover {
            background-color: #388e3c;
            background: linear-gradient(#4f46e5, #3730a3);
            transform: translateY(-2px);
        }

        .button.delete {
            background-color: #f44336;
            color: #ffffff;
            cursor: pointer;
        }

        .button.delete:hover {
            background-color: #d32f2f;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            table thead th,
            table tbody td {
                font-size: 12px;
                padding: 8px;
            }
        }

</style>

<script>
	window.addEventListener('load', function()
	 {
		history.pushState(null, document.title, location.href);
		window.addEventListener('popstate', function(event)
		{
			history.pushState(null, document.title, location.href);            
		});
	});
</script>



	<!-- angular js -->
	<script src="js/angular-1.3.js"></script>
	<script src="js/angular_cookies.js"></script>
	
	</head>
	<body   ng-controller="myappCtrl" style="background-color: #EEEEEE" class="front bg-pattern-dark">
		<div class="body">
			<header id="header">
				<div class="header-top" style="height:8em;">
					<div class="container">
						<a href="#offcanvas" class="uk-navbar-toggle" style="float:left; margin:50px 5px 10px 5px;" data-uk-offcanvas>
							<span class="sr-only">Toggle navigation</span>
							<i class="fa fa-bars"></i>
						</a>
                        <nav>
							<ul class="nav nav-pills nav-top nav-top-left">
								<div class="head">College Voting System</div>
							</ul>
														
							<ul class="nav nav-pills nav-top nav-top-right">
								<li class="login">
									
								</li>
							</ul>
                        </nav>
					</div>	
				</div>
			</header>
			
			<br>
			<div style="font-weight: 100;font-size: 1.6em ;text-align: center;color: #000000" >Update Candidate </div>
            <div class="col-md1 simpleCart_shelfItem">

            <div style="position: relative;left: 10px;">

    <?php if ($isEditMode): ?>
    <div class="form-container">
        <form method="post">
            
            <input type="hidden" name="original_id" value="<?php echo htmlspecialchars($sid); ?>">

            <div class="styled-input">
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($cname ?? ''); ?>" ng-pattern="/^[A-Za-z\s]+$/" oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')" />
            <label for="name">Candidate Name</label>
            </div>

            <div class="styled-input">
            <input type="text" id="sid" name="sid" value="<?php echo htmlspecialchars($sid ?? ''); ?>"/>
            <label for="id">Student Id</label>
            </div>

            <div class="styled-input">
            <select id="position" name="position" required>
            <option value="">Select Position</option>
            <option value="CR" <?php echo (isset($position) && $position == 'CR') ? 'selected' : ''; ?>>CR</option>
            <option value="LR" <?php echo (isset($position) && $position == 'LR') ? 'selected' : ''; ?>>LR</option>
            <option value="GS" <?php echo (isset($position) && $position == 'GS') ? 'selected' : ''; ?>>GS</option>
            <option value="WISE(GS)" <?php echo (isset($position) && $position == 'WISE(GS)') ? 'selected' : ''; ?>>WISE(GS)</option>
            </select>                
            </div>


            <div class="styled-input">
            <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($date ?? ''); ?>"/>
            <label for="assigndate">Assign Date</label>
            </div>

            <div class="styled-input">
            <select id="gender" name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male" <?php echo (isset($gender) && $gender == 'Male') ? 'selected' : ''; ?>>Male</option>
            <option value="Female" <?php echo (isset($gender) && $gender == 'Female') ? 'selected' : ''; ?>>Female</option>
            </select>
            </div>


            <div class="styled-input">
            <input type="text" id="mobile" name="mobile" value="<?php echo htmlspecialchars($mobile ?? ''); ?>" maxlength="10" pattern="^[0-9]{10}$" ng-pattern="/^[0-9]*$/" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            <label for="Mobile">Mobile</label>
            </div>
    
            <div class="styled-input">
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($add ?? ''); ?>" maxlength="80"/>
            <label for="address">Address</label>
            </div>

            <div class="styled-input">
            <select id="department" name="department" required>
            <option value="">Select Department</option>
            <option value="BMIIT" <?php echo (isset($department) && $department == 'BMIIT') ? 'selected' : ''; ?>>BMIIT</option>
            <option value="CGPIT" <?php echo (isset($department) && $department == 'CGPIT') ? 'selected' : ''; ?>>CGPIT</option>
            <option value="BBA" <?php echo (isset($department) && $department == 'BBA') ? 'selected' : ''; ?>>BBA</option>
            <option value="MBA" <?php echo (isset($department) && $department == 'MBA') ? 'selected' : ''; ?>>MBA</option>
            </select>
            </div>


            <div class="styled-input">
            <select id="year" name="year" required>
            <option value="">Select Year</option>
            <option value="1st" <?php echo (isset($year) && $year == '1st') ? 'selected' : ''; ?>>1st</option>
            <option value="2nd" <?php echo (isset($year) && $year == '2nd') ? 'selected' : ''; ?>>2nd</option>
            <option value="3rd" <?php echo (isset($year) && $year == '3rd') ? 'selected' : ''; ?>>3rd</option>
            <option value="4th" <?php echo (isset($year) && $year == '4th') ? 'selected' : ''; ?>>4th</option>
            <option value="5th" <?php echo (isset($year) && $year == '5th') ? 'selected' : ''; ?>>5th</option>
            </select>
            </div>


            <div class="styled-input">
            <input type="submit" name="btnUpdate" value="Update" style="background-color: #FF6929; color: white; border: none; padding: 10px 20px; cursor: pointer;">
            </div>
        </form>
    </div>
    <?php endif; ?>

    <div style="position: relative; left: 10px;">
        <form class="form">
            <div class="styled-input">
                <input type="text" id="searchInput" onkeyup="searchTable()"  required />
                <label>Search</label>
                <span></span> 
            </div>
        </form>
    </div>

    <div class="table-container">
        <table id="candidateTable">
            <thead>
						<tr>
                        <th>Symbol</th>
						<th>Candidate Name</th>
						<th>StudentID</th>
						<th>Dept</th>
						<th>Year</th>
                        <th>Date</th>
						<th>Gender</th>
						<th>Address</th>
						<th>Mobile</th>
                        <th>Position</th>
						<th>Actions</th>
						</tr>
            </thead>
            <tbody>
                <?php
                while ($row = $result->fetch_assoc()) {
                    $id = $row['id']; // Get the unique id
                    echo "<tr>";
                    echo "<td><img width='80' height='80' src='" . htmlspecialchars($row['image']) . "' /></td>";
                    echo "<td>" . htmlspecialchars($row['candidate_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Department']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Year']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Gender']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['mobile']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Position']) . "</td>";
                    echo "<td>";
                    echo "<form method='post' style='display:inline;'>";
                    echo "<input type='hidden' name='id' value='$id'>";
                    echo "<input type='submit' name='btnEdit' value='Update' class='button edit'>";
                    echo "<input type='submit' name='btndelete' value='Delete' class='button delete'>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
		<br>
		</div>

        </div>
        <div id="offcanvas" class="uk-offcanvas">
            <div class="uk-offcanvas-bar">
				<ul id="main-menu-offcanvas" class="uk-nav-offcanvas" data-uk-nav>
					<h2 style="color:#000;font-size:25px;padding:1.5em;margin-bottom:15px;font-weight:bold;font-family:Quicksand;">Online Portal</h2>
					<span class="uk-parent">
						<a href="home.html"><img src="images/icons/house.png" class="fa icon"> &nbsp;&nbsp;&nbsp;Home</a>
					</span>
                    
                    <span class="uk-parent">
						<a style="cursor:pointer" ng-click="user_logout()"><img src="images/icons/smartphone-2.png" class="fa icon"> &nbsp;&nbsp;&nbsp;Logout</a>
					</span>
				</ul>
			</div>
		</div>
	
		<!-- Vendor -->
		<script src="vendor/jquery.validation/jquery.validation.js"></script>
		<script src="vendor/owlcarousel/owl.carousel.js"></script>
		<script src="vendor/flexslider/jquery.flexslider-min.js"></script>
		<script src="vendor/countdown/countdown.min.js"></script>
		<script src="vendor/chosen/chosen.jquery.min.js"></script>
		<script src="vendor/pricefilter/jquery.pricefilter.js"></script>
		<script src="vendor/masonry/imagesloaded.pkgd.min.js"></script>
		<script src="vendor/masonry/masonry.pkgd.min.js"></script>
		<script src="vendor/uikit/uikit.js"></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>

		<!-- Theme Base, Components and Settings -->
		<script src="js/theme.js"></script>
		
		<!-- Style Switcher -->
		<script type="text/javascript" src="style-switcher/js/switcher.js"></script>


        <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
        <script type="text/javascript" src="js/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
        <script type="text/javascript">
            $('.form_datetime').datetimepicker({
                //language:  'fr',
                weekStart: 1,
                todayBtn:  1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: 1
            });
            $('.form_date').datetimepicker({
                language:  'fr',
                weekStart: 1,
                todayBtn:  1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                minView: 2,
                forceParse: 0
            });
            $('.form_time').datetimepicker({
                language:  'fr',
                weekStart: 1,
                todayBtn:  1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 1,
                minView: 0,
                maxView: 1,
                forceParse: 0
            });
        </script>
<body onload="onLoad()">	
    <script src="js/script.js"></script>	
</body>
</html>
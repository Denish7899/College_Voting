
1. Place the coding in below path 
c:\xampp\htdocs\projects\college_voting\web

2. Opent  localhost/phpmyadmin
   Crete DB - college_voting_maniya 
   
3. Import college_voting_maniya.sql 

4. For Project run the path in browser

localhost/projects/college_voting/web/

Admin
admin@gmail.com
test

User
SL123456


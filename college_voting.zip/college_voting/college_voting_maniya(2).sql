-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2024 at 04:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college_voting_maniya`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `cus_id` int(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `candidate_name` varchar(100) NOT NULL,
  `id` varchar(100) NOT NULL,
  `Department` varchar(300) NOT NULL,
  `Year` varchar(300) NOT NULL,
  `date` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `Position` varchar(50) DEFAULT NULL,
  `count` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`cus_id`, `email`, `candidate_name`, `id`, `Department`, `Year`, `date`, `Gender`, `address`, `mobile`, `Position`, `count`, `image`, `created_date`) VALUES
(52, 'admin@gmail.com', 'Dhruvin', '202206100110009', 'BBA', '4th', '2024-11-14', 'Male', 'ABCD', '9727864872', 'GS', '1', 'http://localhost/projects/college_voting/web/uploads/teamwork.png', '2024-11-14'),
(53, 'admin@gmail.com', 'Jay', '202206100110028', 'CGPIT', '5th', '2024-11-15', 'Male', 'ABCD', '9278473453', 'CR', '2', 'http://localhost/projects/college_voting/web/uploads/trophy.png', '2024-11-14'),
(54, 'admin@gmail.com', 'Divyesh', '202206100110092', 'MBA', '3rd', '2024-11-15', 'Male', 'ABC', '9747253642', 'CR', '', 'http://localhost/projects/college_voting/web/uploads/finances.png', '2024-11-14'),
(55, 'admin@gmail.com', 'Krish', '202206100110029', 'BMIIT', '5th', '2024-11-14', 'Male', 'ABC', '9642564294', 'CR', '1', 'http://localhost/projects/college_voting/web/uploads/medal.png', '2024-11-14'),
(56, 'admin@gmail.com', 'Yash', '202206100110093', 'BMIIT', '4th', '2025-10-14', 'Male', 'ABC', '7990952045', 'CR', '', 'http://localhost/projects/college_voting/web/uploads/house.png', '2024-11-14');

-- --------------------------------------------------------

--
-- Table structure for table `election_date`
--

CREATE TABLE `election_date` (
  `cus_id` int(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `start_date` varchar(100) NOT NULL,
  `start_time` varchar(100) NOT NULL,
  `end_date` varchar(300) NOT NULL,
  `end_time` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `election_date`
--

INSERT INTO `election_date` (`cus_id`, `email`, `start_date`, `start_time`, `end_date`, `end_time`) VALUES
(11, 'admin@gmail.com', '2024-11-15', '01:00', '2024-11-15', '24:00');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `cus_id` int(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `candidate_id` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `date` varchar(300) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`cus_id`, `email`, `candidate_id`, `year`, `date`, `created_date`) VALUES
(4, 'SL223344', 'SL998855', '1st', '2024-04-06', '2024-06-04'),
(5, 'SL123456', 'SL998855', '1st', '2024-04-06', '2024-07-30'),
(6, '202206100110038', 'SL123456', '1st', '2024-04-06', '2024-10-14'),
(7, '202206100110038', '202206100110067', '2nd', '2024-04-29', '2024-10-26'),
(8, '202206100110038', '202206100110067', '4th', '2024-11-12', '2024-11-11'),
(9, '202206100110038', '202206100110035', '3rd', '2024-11-11', '2024-11-11'),
(10, '202206100110022', '202206100110001', '5th', '2024-11-12', '2024-11-12'),
(11, '202206100110038', '202206100110030', '2nd', '2024-11-13', '2024-11-13'),
(12, '202206100110038', '202206100110029', '', '2024-11-14', '2024-11-14'),
(13, '', '202206100110009', '', '2024-11-14', '2024-11-14'),
(14, '', '202206100110028', '', '2024-11-15', '2024-11-14'),
(15, '202206100110021', '202206100110028', '', '2024-11-15', '2024-11-14');

-- --------------------------------------------------------

--
-- Table structure for table `sms_count`
--

CREATE TABLE `sms_count` (
  `cus_id` int(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `count` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `sms_count`
--

INSERT INTO `sms_count` (`cus_id`, `email`, `count`) VALUES
(11, 'admin@gmail.com', '58');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `cus_id` int(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `father_name` varchar(300) NOT NULL,
  `age` date NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `otp_1` varchar(100) DEFAULT NULL,
  `otp_2` varchar(100) DEFAULT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`cus_id`, `type`, `email`, `student_id`, `name`, `father_name`, `age`, `gender`, `address`, `city`, `year`, `department`, `pincode`, `mobile`, `otp_1`, `otp_2`, `created_date`) VALUES
(45, 'master', 'admin@gmail.com', 'admin@gmail.com', 'ADMIN', 'ADMIN', '2000-12-31', 'Male', 'ABC', 'Surat', '3rd', 'BMIIT', '111111', '7990952045', 'test', '29208', '2021-10-29'),
(46, 'Student', 'admin@gmail.com', '202206100110038', 'PREET', 'PARESHBHAI', '2007-09-18', 'Male', 'ABC', 'Navsari', '3rd', 'BMIIT', '395005', '7990952045', '88988', '44839', '2024-10-14'),
(48, 'Student', 'admin@gmail.com', '202206100110021', 'MEET', 'ABC', '2004-06-21', 'Male', 'ABC', 'Valsad', '1st', 'BMIIT', '396006', '7990952045', '16517', '53830', '2024-10-22'),
(66, 'Student', 'admin@gmail.com', '202206100110022', 'Moni', 'ABC', '2001-12-12', 'Male', 'ABC', 'Surat', '3rd', 'BMIIT', '395005', '7990952045', 'test', '56759', '0000-00-00'),
(67, 'Student', 'admin@gmail.com', '202206100110023', 'Prince', 'ABC', '2002-03-12', 'Male', 'ABC', 'Bharuch', '3rd', 'CGPIT', '432231', '7990952045', 'test', NULL, '2024-11-12'),
(88, 'Student', 'admin@gmail.com', '202206100110024', 'Krish', 'ABC', '2003-02-19', 'Male', 'ABC', 'Vadodara', '3rd', 'CGPIT', '395005', '7990952045', 'test', NULL, '2024-11-12'),
(90, 'Student', 'admin@gmail.com', '202206100110025', 'Jay', 'ABCD', '2024-11-20', 'Male', 'ABC', 'Surat', '4th', 'BMIIT', '395005', '9827484984', NULL, NULL, '2024-11-14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `election_date`
--
ALTER TABLE `election_date`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `sms_count`
--
ALTER TABLE `sms_count`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`cus_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `cus_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `election_date`
--
ALTER TABLE `election_date`
  MODIFY `cus_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `cus_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `sms_count`
--
ALTER TABLE `sms_count`
  MODIFY `cus_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `cus_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
